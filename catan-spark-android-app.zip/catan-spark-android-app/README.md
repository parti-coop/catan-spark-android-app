# 빠띠앱

## 개발환경

${프로젝트 최상위 폴더}/local.properties 에 개발 환경에 맞는 API base 주소를 설정합니다. 반드시 /로 끝나야합니다.

```
debug.api.base.url=https://parti.test/
```

FCM에서 받아온 google-services.json을 ${프로젝트 최상위 폴더}/app에 넣어 둡니다.
